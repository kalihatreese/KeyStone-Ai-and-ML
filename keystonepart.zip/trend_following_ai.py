import numpy as np
import pandas as pd
import talib
from prophet import Prophet

class TrendFollowingAI:
    def __init__(self):
        self.model = Prophet()
        self.ema_short = 50
        self.ema_long = 200
        self.atr_period = 14
        
    def calculate_indicators(self, data):
        close_prices = data['close'].values
        high_prices = data['high'].values
        low_prices = data['low'].values
        
        ema_short = talib.EMA(close_prices, timeperiod=self.ema_short)
        ema_long = talib.EMA(close_prices, timeperiod=self.ema_long)
        atr = talib.ATR(high_prices, low_prices, close_prices, timeperiod=self.atr_period)
        
        return {
            'ema_short': ema_short,
            'ema_long': ema_long,
            'atr': atr
        }
    
    def predict(self, data):
        indicators = self.calculate_indicators(data)
        
        # Trend-following strategy
        if indicators['ema_short'][-1] > indicators['ema_long'][-1]:
            return "BUY"
        elif indicators['ema_short'][-1] < indicators['ema_long'][-1]:
            return "SELL"
        else:
            return "HOLD"
    
    def execute_trade(self, decision):
        # Placeholder for trade execution logic
        print(f"Trend-Following AI executing trade: {decision}")
